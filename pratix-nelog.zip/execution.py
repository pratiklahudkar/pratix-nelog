import sys
import os

# Add the parent directory to the Python path
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from pratix_nelog.parser import LogParser
from pratix_nelog.consolidator import LogConsolidator

# Example usage
logs = LogParser.parse_csv("sample_logs.csv")
consolidated_logs = LogConsolidator.consolidate(logs, "csv")
LogConsolidator.save_to_json(consolidated_logs, "output.json")

print("Logs processed and saved to output.json")
