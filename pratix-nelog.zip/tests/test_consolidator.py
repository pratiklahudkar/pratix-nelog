from pratix_nelog.consolidator import LogConsolidator

def test_consolidate():
    logs = [{"timestamp": "2025-01-01", "ip": "192.168.1.1", "action": "allow"}]
    result = LogConsolidator.consolidate(logs, "csv")
    assert result[0]["timestamp"] == "2025-01-01"
