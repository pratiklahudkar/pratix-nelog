# tests/test_parser.py
from pratix_nelog.parser import LogParser

def test_parse_csv():
    logs = LogParser.parse_csv("tests/sample.csv")
    assert len(logs) > 0
    assert "timestamp" in logs[0]
